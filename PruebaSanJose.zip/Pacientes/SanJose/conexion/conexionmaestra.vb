﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Module conexionmaestra
    Public conexion As SqlConnection = New SqlConnection("Data Source=DESKTOP-7JMI48O\SQLEXPRESS;Initial Catalog=dbprueba;Integrated Security=True")

    Sub abrir_conexion()
        If conexion.State = 0 Then
            conexion.Open()
        End If
    End Sub

    Sub cerrar_conexion()
        If conexion.State = 1 Then
            conexion.Close()
        End If
    End Sub
End Module
