﻿Public Class Reporte
    Private Sub CrystalReportViewer1_Load(sender As Object, e As EventArgs) Handles CrystalReportViewer1.Load

    End Sub

    Private Sub Reporte_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim objrep As New CrystalReport1
        CrystalReportViewer1.ReportSource = objrep
    End Sub
End Class