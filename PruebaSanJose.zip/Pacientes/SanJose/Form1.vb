﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load

        mostrar()
    End Sub

    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        Dim cmd As New SqlCommand

        If txtID.Text <> "" And txtNombre.Text <> "" Then
            Try
                abrir_conexion()
                cmd = New SqlCommand("Insertar_Paciente", conexion)
                cmd.CommandType = 4
                cmd.Parameters.AddWithValue("@ID_Paciente", txtID.Text)
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.ToString)
                cmd.Parameters.AddWithValue("@Apellido_Paterno", txtApellidoP.Text.ToString)
                cmd.Parameters.AddWithValue("@Apellido_Materno", txtApellidoM.Text.ToString)
                cmd.Parameters.AddWithValue("@Fecha_de_Nacimiento", txtFechaN.Text.ToString)
                cmd.Parameters.AddWithValue("@Sexo", cbxSexo.Text.ToString)
                cmd.Parameters.AddWithValue("@Dirreccion", txtDirreccion.Text.ToString)
                cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text)
                cmd.Parameters.AddWithValue("@Fecha_Registro", txtFechaR.Text.ToString)
                cmd.ExecuteNonQuery()
                cerrar_conexion()
                Limpiar()
                mostrar()
            Catch ex As Exception

            End Try
        Else
            MessageBox.Show("Tiene que llenar los campos ID y Nombre")
        End If
    End Sub

    Sub mostrar()
        Dim dt As New DataTable
        Dim da As SqlDataAdapter

        Try
            abrir_conexion()
            da = New SqlDataAdapter("Mostrar_Paciente", conexion)
            da.Fill(dt)
            dvgPacientes.DataSource = dt
            cerrar_conexion()
        Catch ex As Exception

        End Try
    End Sub

    Sub Limpiar()
        txtID.Text = ("")
        txtNombre.Text = ("")
        txtApellidoP.Text = ("")
        txtApellidoM.Text = ("")
        txtCorreoE.Text = ("")
        txtDirreccion.Text = ("")
        txtFechaN.Text = ("")
        txtFechaR.Text = ("")
        txtTelefono.Text = ("")
        cbxSexo.Text = ("")
    End Sub
    Private Sub btnModificar_Click(sender As Object, e As EventArgs) Handles btnModificar.Click
        Dim cmd As New SqlCommand

        If txtID.Text <> "" And txtNombre.Text <> "" Then
            Try
                abrir_conexion()
                cmd = New SqlCommand("Editar_Paciente", conexion)
                cmd.CommandType = 4
                cmd.Parameters.AddWithValue("@ID_Paciente", txtID.Text)
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text.ToString)
                cmd.Parameters.AddWithValue("@Apellido_Paterno", txtApellidoP.Text.ToString)
                cmd.Parameters.AddWithValue("@Apellido_Materno", txtApellidoM.Text.ToString)
                cmd.Parameters.AddWithValue("@Fecha_de_Nacimiento", txtFechaN.Text.ToString)
                cmd.Parameters.AddWithValue("@Sexo", cbxSexo.Text.ToString)
                cmd.Parameters.AddWithValue("@Dirreccion", txtDirreccion.Text.ToString)
                cmd.Parameters.AddWithValue("@Telefono", txtTelefono.Text)
                cmd.Parameters.AddWithValue("@Fecha_Registro", txtFechaR.Text.ToString)
                cmd.ExecuteNonQuery()
                cerrar_conexion()
                Limpiar()
                mostrar()
            Catch ex As Exception

            End Try
        Else
            MessageBox.Show("Tiene que llenar los campos ID y Nombre")
        End If
    End Sub

    Private Sub dvgPacientes_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles dvgPacientes.CellContentDoubleClick
        Try
            txtID.Text = dvgPacientes.SelectedCells.Item(1).Value
            txtNombre.Text = dvgPacientes.SelectedCells.Item(2).Value
            txtApellidoP.Text = dvgPacientes.SelectedCells.Item(3).Value
            txtApellidoM.Text = dvgPacientes.SelectedCells.Item(4).Value
            txtFechaN.Text = dvgPacientes.SelectedCells.Item(5).Value
            cbxSexo.Text = dvgPacientes.SelectedCells.Item(6).Value
            txtDirreccion.Text = dvgPacientes.SelectedCells.Item(7).Value
            txtTelefono.Text = dvgPacientes.SelectedCells.Item(8).Value
            txtCorreoE.Text = dvgPacientes.SelectedCells.Item(9).Value
            txtFechaR.Text = dvgPacientes.SelectedCells.Item(10).Value
        Catch ex As Exception

        End Try
    End Sub

    Private Sub dvgPacientes_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dvgPacientes.CellContentClick
        If e.ColumnIndex = dvgPacientes.Columns.Item("Eliminar").Index Then
            Dim result As DialogResult
            result = MsgBox("El registro sera eliminado ¿Seguro?", vbQuestion + vbOKCancel)
            If result = DialogResult.OK Then
                Dim cmd As SqlCommand
                Try
                    abrir_conexion()
                    cmd = New SqlCommand("Eliminar_Paciente", conexion)
                    cmd.CommandType = 4
                    cmd.Parameters.AddWithValue("@ID_Paciente", dvgPacientes.SelectedCells.Item(1).Value)
                    cmd.ExecuteNonQuery()
                    cerrar_conexion()
                Catch ex As Exception

                End Try
            Else
                MsgBox("Eliminacion cancelada", vbOKOnly)
            End If
        End If
    End Sub

    Private Sub btnReporte_Click(sender As Object, e As EventArgs) Handles btnReporte.Click
        Reporte.Show()
    End Sub
End Class
